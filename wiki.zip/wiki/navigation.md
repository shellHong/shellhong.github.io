# 文档平台

[业务文档]()

  * [cp deeplink活动模版说明](business/deeplink.md)
  * [外部应用跳转应用商店](appstore/deeplink.md)
  * [单应用配置说明](appstore/scene.md)
  * [导航页面配置说明](appstore/scene_nav.md)
